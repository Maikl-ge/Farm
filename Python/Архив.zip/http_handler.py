from aiohttp import web

async def show_data(request):
    async with request.app['db_pool'].acquire() as conn:
        records = await conn.fetch('SELECT * FROM sensor_data')

    if records:
        html_content = "<h1>Сохраненные данные</h1><table border='1'><tr>"
        headers = ["id", "timestamp", "current_date", "current_time", "start_button", "stop_button", "mode_button",
                   "max_osmo_level", "min_osmo_level", "max_water_level", "min_water_level",
                   "temperature_1", "humidity_1", "temperature_2", "humidity_2", "temperature_3", "humidity_3",
                   "temperature_4", "humidity_4", "temperature_5", "humidity_5",
                   "water_temperature_osmo", "water_temperature_watering",
                   "air_temperature_outdoor", "air_temperature_inlet", "ph_osmo", "tds_osmo", "power_monitor"]
        html_content += ''.join([f"<th>{header}</th>" for header in headers])
        html_content += "</tr>"
        for record in records:
            html_content += "<tr>"
            html_content += ''.join([f"<td>{record[header]}</td>" for header in headers])
            html_content += "</tr>"
        html_content += "</table>"
    else:
        html_content = "<h1>Нет сохраненных данных.</h1>"

    html_content += """
    <script>
    let socket = new WebSocket("ws://localhost:5001");

    socket.onopen = function(e) {
        console.log("[open] Соединение установлено");
    };

    socket.onmessage = function(event) {
        console.log(`[message] Данные получены с сервера: ${event.data}`);
    };

    socket.onclose = function(event) {
        if (event.wasClean) {
            console.log(`[close] Соединение закрыто чисто, код=${event.code} причина=${event.reason}`);
        } else {
            console.log('[close] Соединение прервано');
        }
    };

    socket.onerror = function(error) {
        console.log(`[error] ${error.message}`);
    };

    function sendData() {
        let input = document.getElementById("dataInput").value;
        socket.send(JSON.stringify({ message: input }));
        console.log(`Отправлено сообщение: ${input}`);
    }
    </script>
    """

    return web.Response(text=html_content, content_type='text/html')