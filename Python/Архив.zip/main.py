import asyncio
from aiohttp import web
import websockets
from database import create_db_pool
from websocket_handler import handle_connection, send_test_message, check_websocket_state
from http_handler import show_data

async def main():
    port = 5001  # Порт для WebSocket-сервера
    http_port = 8080  # Порт для HTTP-сервера
    print(f"Сервер запущен на порту {port}...")

    db_pool = await create_db_pool()
    app = web.Application()
    app['db_pool'] = db_pool

    # Запуск задач для отправки тестовых сообщений и проверки состояния WebSocket
    asyncio.create_task(send_test_message())
    asyncio.create_task(check_websocket_state())

    # Установка параметров ping_interval и ping_timeout
    websocket_server = await websockets.serve(
        lambda ws, path: handle_connection(ws, path, db_pool),
        "0.0.0.0", port,
        ping_interval=5,  # Интервал пингов в секундах
        ping_timeout=5   # Таймаут для ответа на пинг в секундах
    )

    app.router.add_get("/data", show_data)
    web_server = web.AppRunner(app)
    await web_server.setup()
    site = web.TCPSite(web_server, "0.0.0.0", http_port)
    await site.start()

    await websocket_server.wait_closed()

if __name__ == "__main__":
    asyncio.run(main())