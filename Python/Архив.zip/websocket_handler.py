# Импорты и глобальные переменные
import asyncio
import websockets
from datetime import datetime
import json
from database import save_sensor_data  # Функция для сохранения данных в базу данных
from utils import safe_get  # Утилита для безопасного получения значений
from collections import Counter

# Множество для отслеживания подключённых клиентов
connected_clients = set()

# Переменная для хранения состояния WebSocket
websocket_state = None

# Функции для управления состоянием WebSocket
def update_websocket_state(new_state):
# Обновляет состояние WebSocket, если оно изменилось.
    global websocket_state
    if websocket_state != new_state:
        websocket_state = new_state
        print(f"WebSocket state changed to: {websocket_state}")


async def check_websocket_state():
# Периодически проверяет наличие подключённых клиентов и обновляет состояние WebSocket.
    while True:
        await asyncio.sleep(5)
        if connected_clients:
            update_websocket_state("connected")
        else:
            update_websocket_state("disconnected")

# Вспомогательные функции
async def send_test_message():

    # Периодически отправляет тестовое сообщение всем подключённым клиентам.
    while True:
        await asyncio.sleep(25)
        clients_to_notify = list(connected_clients)  # Копируем клиентов для безопасной итерации
        for client in clients_to_notify:
            try:
                await client.send("SRSE")
            except websockets.ConnectionClosed:
                pass  # Игнорируем отключённые клиенты

# Основные функции обработки WebSocket
async def handle_connection(websocket, path, db_pool):
    try:
        print(f"Клиент подключен по пути: {path}")
        connected_clients.add(websocket)
        update_websocket_state("connected")

        while True:
            message = await websocket.recv()
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            print(f"{timestamp} - Получено сообщение: {message}")

            try:
                parts = message.split(' ', 3)
                if len(parts) < 4:
                    raise ValueError("Неверный формат сообщения")
                    
                id_farm = parts[0]
                type_msg = parts[1]
                json_length = parts[2]
                message = ' '.join(parts[3:])
                
                # Проверка длины JSON данных
                if len(message) != int(json_length):
                    raise ValueError("Несоответствие длины JSON данных")
                
                if type_msg in MESSAGE_HANDLERS:
                    await MESSAGE_HANDLERS[type_msg](message, db_pool, timestamp)
                else:
                    print(f"{timestamp} - Получено сообщение неизвестного типа: {type_msg}")

            except (ValueError, IndexError) as e:
                print(f"{timestamp} - Ошибка обработки сообщения: {e}")
                continue

    except websockets.exceptions.ConnectionClosed:
        print("Клиент отключился")
    finally:
        connected_clients.remove(websocket)
        update_websocket_state("disconnected")

async def process_flin_message(message, db_pool, timestamp):
    # Обрабатывает сообщения типа FLIN.
    try:
        # Парсим данные из JSON     
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные: {data}")
        # Сохраняем данные в базу данных
        async with db_pool.acquire() as conn:
            await save_sensor_data(conn, data, timestamp)
        print(f"{timestamp} - Данные сохранены в PostgreSQL")
    except json.JSONDecodeError as e:
        print(f"{timestamp} - Ошибка при парсинге JSON: {e}")
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке сообщения: {e}")

async def process_frqw_message(message, db_pool, timestamp):
    # Обрабатывает сообщения типа FRQW.
    try:
        # Парсим данные из JSON
        data = json.loads(message)
        # Выводим распарсенные данные в консоль
        print(f"{timestamp} - Распарсенные данные: {data}")
    except json.JSONDecodeError as e:
        # Обрабатываем ошибку парсинга JSON
        print(f"{timestamp} - Ошибка при парсинге FRQW: {e}")

async def process_frqd_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FRQD: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FRQD: {e}")

async def process_frqs_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FRQS: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FRQS: {e}")

async def process_frqp_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FRQP: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FRQP: {e}")

async def process_frqf_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FRQF: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FRQF: {e}")

async def process_frqc_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FRQC: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FRQC: {e}")

async def process_fdst_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FDST: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FDST: {e}")

async def process_fdtl_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FDTL: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FDTL: {e}")

async def process_fder_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FDER: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FDER: {e}")

async def process_fdev_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FDEV: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FDEV: {e}")

async def process_fldb_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FLDB: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FLDB: {e}")

async def process_fler_message(message, db_pool, timestamp):
    try:
        data = json.loads(message)
        print(f"{timestamp} - Распарсенные данные FLER: {data}")
        return data
    except Exception as e:
        print(f"{timestamp} - Ошибка при обработке FLER: {e}")



MESSAGE_HANDLERS = {
    # Типы запросов
    "FRQW": process_frqw_message,    # Ответ статуса фермы на запрос сервера
    "FRQD": process_frqd_message,    # Ответ с данными фермы на запрос сервера
    "FRQS": process_frqs_message,    # Ответ настроек фермы на запрос сервера
    "FRQP": process_frqp_message,    # Ответ параметров фермы на запрос сервера
    "FRQF": process_frqf_message,    # Ответ профиля фермы на запрос сервера
    "FRQC": process_frqc_message,    # Ответ текущих данных фермы

    # Типы данных
    "FDST": process_fdst_message,    # Ответ Статус фермы
    "FDTL": process_fdtl_message,    # Телеметрические данные фермы
    "FDER": process_fder_message,    # Сообщение об ошибке фермы
    "FDEV": process_fdev_message,    # Событие фермы

    # Логи и отладка
    "FLIN": process_flin_message,    # Информационное сообщение
    "FLDB": process_fldb_message,    # Отладочное сообщение
    "FLER": process_fler_message     # Ошибка
}      

message_stats = Counter()

async def process_any_message(message, db_pool, timestamp):
    type_msg = message[:4]
    message_stats[type_msg] += 1
    # ... остальная логика обработки      